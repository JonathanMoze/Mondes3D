#include "accelerators/bvh.h"
#include "shapes/mesh.h"

#include <algorithm>
#include <iostream>

void BVH::build(const Mesh *pMesh, int targetCellSize, int maxDepth) {
  m_pMesh = pMesh;
  m_nodes.resize(1);
  if (m_pMesh->nbFaces() <= targetCellSize) {
    m_nodes[0].box = pMesh->getBoundingBox();
    m_nodes[0].first_face_id = 0;
    m_nodes[0].is_leaf = true;
    m_nodes[0].nb_faces = m_pMesh->nbFaces();
    m_faces.resize(m_pMesh->nbFaces());
    for (int i = 0; i < m_pMesh->nbFaces(); ++i) {
      m_faces[i] = i;
    }
  } else {
    m_nodes.reserve(std::min<int>(
        2 << maxDepth, std::log(m_pMesh->nbFaces() / targetCellSize)));
    
    // compute centroids and initialize the face list
    m_centroids.resize(m_pMesh->nbFaces());
    m_faces.resize(m_pMesh->nbFaces());
    for (int i = 0; i < m_pMesh->nbFaces(); ++i) {
      m_centroids[i] = (m_pMesh->vertexOfFace(i, 0).position +
                        m_pMesh->vertexOfFace(i, 1).position +
                        m_pMesh->vertexOfFace(i, 2).position) /
                       3.f;
      m_faces[i] = i;
    }
    buildNode(0, 0, m_pMesh->nbFaces(), 0, targetCellSize, maxDepth);
  }
}

int niveau = 0;

void BVH::intersect(const Ray &ray, Hit &hit) const {
  // compute the intersection with the root node
  float tMin, tMax;
  Normal3f n;
  
  // TODO
  // vérifier si on a bien une intersection (en fonction de tMin, tMax, et
  // hit.t()), et si oui appeler intersecNode...
  if(!m_nodes[0].box.rayIntersect(ray, tMin, tMax) || tMin > hit.t){
    return; 
  }

  
  intersectNode(0, ray, hit);
}



void BVH::intersectNode(int nodeId, const Ray &ray, Hit &hit) const {
  // TODO, deux cas: soit mNodes[nodeId] est une feuille (il faut alors
  // intersecter les triangles du noeud), soit c'est un noeud interne (il faut
  // visiter les fils (ou pas))  

  if(m_nodes[nodeId].is_leaf){
    Hit hitTest = Hit();
    for(int i=0; i<m_nodes[nodeId].nb_faces; i++){
      m_pMesh->intersectFace(ray, hitTest, m_faces[m_nodes[nodeId].first_face_id+i]);
      if (hitTest.t < hit.t)
        hit=hitTest;
    }
    return;
    
  }

  float tNear1, tFar1, tNear2, tFar2;
  bool intersect1= m_nodes[m_nodes[nodeId].first_child_id].box.rayIntersect(ray, tNear1, tFar1);
  bool intersect2 = m_nodes[m_nodes[nodeId].first_child_id+1].box.rayIntersect(ray, tNear2, tFar2);
  if((intersect1 && tNear1 <= hit.t) && (intersect2 && tNear2 <= hit.t)){
      Hit hit1 = Hit();
      Hit hit2 = Hit();
      intersectNode(m_nodes[nodeId].first_child_id, ray, hit1);
      intersectNode(m_nodes[nodeId].first_child_id+1, ray, hit2);
      if(hit1.t < hit2.t){
        hit = hit1;
      } else {
        hit = hit2;
      }
      return;
  } else if ((intersect1 && tNear1 <= hit.t)){
    intersectNode(m_nodes[nodeId].first_child_id, ray, hit);
    return;
  } else if ((intersect2 && tNear2 <= hit.t)) {

    intersectNode(m_nodes[nodeId].first_child_id+1, ray, hit);
    return;
  }

}

/** Sorts the faces with respect to their centroid along the dimension \a dim
 * and spliting value \a split_value. \returns the middle index
 */
int BVH::split(int start, int end, int dim, float split_value) {
  int l(start), r(end - 1);
  while (l < r) {
    // find the first on the left
    while (l < end && m_centroids[l](dim) < split_value)
      ++l;
    while (r >= start && m_centroids[r](dim) >= split_value)
      --r;
    if (l > r)
      break;
    std::swap(m_centroids[l], m_centroids[r]);
    std::swap(m_faces[l], m_faces[r]);
    ++l;
    --r;
  }
  return m_centroids[l][dim] < split_value ? l + 1 : l;
}

void BVH::buildNode(int nodeId, int start, int end, int level,
                    int targetCellSize, int maxDepth) {

  Node &node = m_nodes[nodeId];

  // étape 1 : calculer la boite englobante des faces indexées de m_faces[start]
  // à m_faces[end] (Utiliser la fonction extend de Eigen::AlignedBox3f et la
  // fonction mpMesh->vertexOfFace(int) pour obtenir les coordonnées des sommets
  // des faces)
  BoundingBox3f box_tmp = BoundingBox3f();
  for(int findex = start; findex<end; findex++){
    for(int vIndex = 0; vIndex<3; vIndex++){
      box_tmp.expandBy(m_pMesh->vertexOfFace(m_faces[findex], vIndex).position);
    }
  }
 
  

  // étape 2 : déterminer si il s'agit d'une feuille (appliquer les critères
  // d'arrêts)
  // Si c'est une feuille, finaliser le noeud et quitter la fonction
  if(level == maxDepth || end-start<targetCellSize){
    node.is_leaf = 1;
    node.box = box_tmp;
    node.first_face_id = start;
    node.nb_faces = (end-start);

    return;
  }

    
  // Si c'est un noeud interne :

  // étape 3 : calculer l'index de la dimension (x=0, y=1, ou z=2) et la valeur
  // du plan de coupe (on découpe au milieu de la boite selon la plus grande
  // dimension)
  int axis = box_tmp.getMajorAxis();
  float splitVal = box_tmp.getCenter()[axis];

  // étape 4 : appeler la fonction split pour trier (partiellement) les faces et
  // vérifier si le split a été utile
  int middle = split(start, end, axis, splitVal);
    
  while(middle == start || middle == end)
  {
    axis = (axis+1)%3;
    splitVal = box_tmp.getCenter()[axis];
    middle = split(start, end, axis, splitVal);
  }
  //printf("middle index is %d    start: %d   and end: %d\n", middle_index, start, end);
  // étape 5 : allouer les fils, et les construire en appelant buildNode...
  // Pas besoin de vérifier la taille du vecteur grâce à la fonction emplace_back qui s'en charge
  
  if(nodeId*2+2>= m_nodes.size()){
    m_nodes.resize((m_nodes.size()*2+2));
  }

  
  m_nodes[nodeId].box = box_tmp;
  m_nodes[nodeId].is_leaf = 0;
  m_nodes[nodeId].nb_faces = (end-start);
  m_nodes[nodeId].first_child_id = (nodeId*2)+1;

   

  buildNode((nodeId*2)+1, start, middle, level+1, targetCellSize, maxDepth);
  buildNode((nodeId*2)+2, middle, end, level+1, targetCellSize, maxDepth);

  
}
