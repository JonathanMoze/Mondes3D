/*
    This file is part of Nori, a simple educational ray tracer

    Copyright (c) 2015 by Wenzel Jakob

    Nori is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License Version 3
    as published by the Free Software Foundation.

    Nori is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include <bitmap.h>

#define TINYEXR_USE_MINIZ (0)
#include <zlib.h>
#define TINYEXR_IMPLEMENTATION
#include <tinyexr.h>

#define STB_IMAGE_WRITE_IMPLEMENTATION
#include <stb_image_write.h>

// Simple tile -> scanline converter. Assumes FLOAT pixel type for all channels.
static void TiledImageToScanlineImage(EXRImage* src, const EXRHeader* header)
{
    size_t data_width  = header->data_window.max_x - header->data_window.min_x + 1;
    size_t data_height = header->data_window.max_y - header->data_window.min_y + 1;

    src->images = static_cast<unsigned char**>(malloc(sizeof(float*) * header->num_channels));
    for (size_t c = 0; c < static_cast<size_t>(header->num_channels); c++) {
        assert(header->pixel_types[c] == TINYEXR_PIXELTYPE_FLOAT);
        src->images[c] = static_cast<unsigned char*>(malloc(sizeof(float) * data_width * data_height));
        memset(src->images[c], 0, sizeof(float) * data_width * data_height);
    }

    for (size_t tile_idx = 0; tile_idx < static_cast<size_t>(src->num_tiles); tile_idx++) {

        int sx = src->tiles[tile_idx].offset_x * header->tile_size_x;
        int sy = src->tiles[tile_idx].offset_y * header->tile_size_y;
        int ex = src->tiles[tile_idx].offset_x * header->tile_size_x + src->tiles[tile_idx].width;
        int ey = src->tiles[tile_idx].offset_y * header->tile_size_y + src->tiles[tile_idx].height;

        for (size_t c = 0; c < static_cast<size_t>(header->num_channels); c++) {
            float *dst_image = reinterpret_cast<float*>(src->images[c]);
            const float *src_image = reinterpret_cast<const float*>(src->tiles[tile_idx].images[c]);
            for (size_t y = 0; y < static_cast<size_t>(ey - sy); y++) {
                for (size_t x = 0; x < static_cast<size_t>(ex - sx); x++) {
                    dst_image[(y + sy) * data_width + (x + sx)] = src_image[y * header->tile_size_x + x];
                }
            }
        }
    }
}

Bitmap::Bitmap(const filesystem::path &filename) {
    if(filename.extension() == "exr")
        loadEXR(filename.str());
    else
        cout << "Unknown file type" << endl;
    return;
}

void Bitmap::loadEXR(const std::string &filename) {
    EXRVersion exr_version;

    int ret = ParseEXRVersionFromFile(&exr_version, filename.c_str());
    if (ret != TINYEXR_SUCCESS) {
        fprintf(stderr, "Invalid EXR file: %s\n", filename.c_str());
        return;
    }

    if (exr_version.multipart) {
        // must be multipart flag is false.
        fprintf(stderr, "Cannot load multi-part EXR\n");
        return;
    }

    EXRHeader exr_header;
    InitEXRHeader(&exr_header);

    const char *err;
    ret = ParseEXRHeaderFromFile(&exr_header, &exr_version, filename.c_str(), &err);
    if (ret != TINYEXR_SUCCESS) {
        fprintf(stderr, "Parse EXR err: %s\n", err);
        return;
    }

    // Read HALF channel as FLOAT.
    for (int i = 0; i < exr_header.num_channels; i++) {
        if (exr_header.pixel_types[i] == TINYEXR_PIXELTYPE_HALF) {
            exr_header.requested_pixel_types[i] = TINYEXR_PIXELTYPE_FLOAT;
        }
    }

    EXRImage exr_image;
    InitEXRImage(&exr_image);

    ret = LoadEXRImageFromFile(&exr_image, &exr_header, filename.c_str(), &err);
    if (ret != TINYEXR_SUCCESS) {
        fprintf(stderr, "Load EXR err: %s\n", err);
        return;
    }

    resize(exr_image.height, exr_image.width);
    cout << "Reading a " << cols() << "x" << rows() << " OpenEXR file from \"" << filename << "\"" << endl;

    if (exr_header.tiled) {
        TiledImageToScanlineImage(&exr_image, &exr_header);
    }

    int idxR = -1, idxG = -1, idxB = -1;
    for (int c = 0; c < exr_header.num_channels; c++) {
        if (strcmp(exr_header.channels[c].name, "R") == 0) {
            idxR = c;
        } else if (strcmp(exr_header.channels[c].name, "G") == 0) {
            idxG = c;
        } else if (strcmp(exr_header.channels[c].name, "B") == 0) {
            idxB = c;
        }
    }

    float *out_rgb = reinterpret_cast<float *>(data());

    for (int i = 0; i < exr_image.width * exr_image.height; i++) {
        out_rgb[3 * i + 0] = reinterpret_cast<float **>(exr_image.images)[idxR][i];
        out_rgb[3 * i + 1] = reinterpret_cast<float **>(exr_image.images)[idxG][i];
        out_rgb[3 * i + 2] = reinterpret_cast<float **>(exr_image.images)[idxB][i];
    }

    FreeEXRImage(&exr_image);
}

void Bitmap::saveEXR(const std::string &filename) {
    cout << "Writing a " << cols() << "x" << rows()
         << " OpenEXR file to \"" << filename << "\"" << endl;

    EXRHeader header;
    InitEXRHeader(&header);

    EXRImage image;
    InitEXRImage(&image);

    image.num_channels = 3;

    std::vector<float> images[3];
    images[0].resize(cols() * rows());
    images[1].resize(cols() * rows());
    images[2].resize(cols() * rows());

    float *rgb = reinterpret_cast<float *>(data());

    for (unsigned int i = 0; i < cols() * rows(); i++) {
        images[0][i] = rgb[3*i+0];
        images[1][i] = rgb[3*i+1];
        images[2][i] = rgb[3*i+2];
    }

    float* image_ptr[3];
    image_ptr[0] = &(images[2].at(0)); // B
    image_ptr[1] = &(images[1].at(0)); // G
    image_ptr[2] = &(images[0].at(0)); // R

    image.images = reinterpret_cast<unsigned char**>(image_ptr);
    image.width = cols();
    image.height = rows();

    header.num_channels = 3;
    header.channels = (EXRChannelInfo *) malloc(sizeof(EXRChannelInfo) * header.num_channels);
    strncpy(header.channels[0].name, "B", 255); header.channels[0].name[strlen("B")] = '\0';
    strncpy(header.channels[1].name, "G", 255); header.channels[1].name[strlen("G")] = '\0';
    strncpy(header.channels[2].name, "R", 255); header.channels[2].name[strlen("R")] = '\0';

    header.pixel_types = (int *) malloc(sizeof(int) * header.num_channels);
    header.requested_pixel_types = (int *) malloc(sizeof(int) * header.num_channels);
    for (int i = 0; i < header.num_channels; i++) {
        header.pixel_types[i] = TINYEXR_PIXELTYPE_FLOAT; // pixel type of input image
        header.requested_pixel_types[i] = TINYEXR_PIXELTYPE_HALF; // pixel type of output image to be stored in .EXR
    }

    header.compression_type = (cols() < 64 || rows() < 64) ? TINYEXR_COMPRESSIONTYPE_NONE :
                                                             TINYEXR_COMPRESSIONTYPE_ZIP;
    const char* err;
    int ret = SaveEXRImageToFile(&image, &header, filename.c_str(), &err);
    if (ret != TINYEXR_SUCCESS) {
        fprintf(stderr, "Save EXR err: %s\n", err);
        return;
    }

    free(header.channels);
    free(header.pixel_types);
    free(header.requested_pixel_types);
}

void Bitmap::savePNG(const std::string &filename, bool tonemap) {
    cout << "Writing a " << cols() << "x" << rows()
         << " PNG file to \"" << filename << "\"" << endl;

    uint8_t *rgb8 = new uint8_t[3 * cols() * rows()];
    uint8_t *dst = rgb8;
    for (int i = 0; i < rows(); ++i) {
        for (int j = 0; j < cols(); ++j) {
            Color3f color;
            if(tonemap)
                color = coeffRef(i, j).toSRGB();
            else 
                color = coeffRef(i, j);
            dst[0] = (uint8_t) clamp(255.f * color[0], 0.f, 255.f);
            dst[1] = (uint8_t) clamp(255.f * color[1], 0.f, 255.f);
            dst[2] = (uint8_t) clamp(255.f * color[2], 0.f, 255.f);
            dst += 3;
        }
    }

    int ret = stbi_write_png(filename.c_str(), (int) cols(), (int) rows(), 3, rgb8, 3 * (int) cols());
    if (ret == 0) {
        cout << "Bitmap::savePNG(): Could not save PNG file \"" << filename << "%s\"" << endl;
    }

    delete[] rgb8;
}
